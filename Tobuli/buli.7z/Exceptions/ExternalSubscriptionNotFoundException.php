<?php

namespace Tobuli\Exceptions;

class ExternalSubscriptionNotFoundException extends \Exception
{
}