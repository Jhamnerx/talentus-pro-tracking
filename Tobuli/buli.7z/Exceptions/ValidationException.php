<?php namespace Tobuli\Exceptions;

class ValidationException extends BaseException {
}   //end of class


//EOF