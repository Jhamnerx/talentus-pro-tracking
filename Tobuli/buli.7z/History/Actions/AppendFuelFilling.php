<?php

namespace Tobuli\History\Actions;

class AppendFuelFilling extends AppendFuelFillingChange
{
}