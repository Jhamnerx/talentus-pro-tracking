<?php

namespace Tobuli\History\Actions;

class AppendFuelTheft extends AppendFuelTheftChange
{
}