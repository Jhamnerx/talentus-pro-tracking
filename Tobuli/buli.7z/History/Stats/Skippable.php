<?php


namespace Tobuli\History\Stats;


interface Skippable
{
    public function setSkipped();
}