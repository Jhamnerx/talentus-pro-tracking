<?php

namespace Tobuli\Clients\Exception;

class LoginFailedException extends \Exception
{
}