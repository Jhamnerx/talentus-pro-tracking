<?php

namespace Tobuli\Clients\Exception;

class ConnectFailedException extends \Exception
{
}