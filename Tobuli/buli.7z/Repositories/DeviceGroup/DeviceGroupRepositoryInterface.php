<?php namespace Tobuli\Repositories\DeviceGroup;

use Tobuli\Repositories\EloquentRepositoryInterface;

interface DeviceGroupRepositoryInterface extends EloquentRepositoryInterface {

}