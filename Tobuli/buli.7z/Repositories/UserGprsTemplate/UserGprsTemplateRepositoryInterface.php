<?php namespace Tobuli\Repositories\UserGprsTemplate;

use Tobuli\Repositories\EloquentRepositoryInterface;

interface UserGprsTemplateRepositoryInterface extends EloquentRepositoryInterface {

}