<?php namespace Tobuli\Repositories\DeviceConfig;

use Tobuli\Repositories\EloquentRepositoryInterface;

interface DeviceConfigRepositoryInterface extends EloquentRepositoryInterface {

}
