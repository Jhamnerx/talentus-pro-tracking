<?php namespace Tobuli\Repositories\Report;

use Tobuli\Repositories\EloquentRepositoryInterface;

interface ReportRepositoryInterface extends EloquentRepositoryInterface {

}