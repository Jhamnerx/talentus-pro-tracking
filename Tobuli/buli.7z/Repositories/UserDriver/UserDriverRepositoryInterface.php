<?php namespace Tobuli\Repositories\UserDriver;

use Tobuli\Repositories\EloquentRepositoryInterface;

interface UserDriverRepositoryInterface extends EloquentRepositoryInterface {

}