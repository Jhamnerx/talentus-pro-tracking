<?php namespace Tobuli\Repositories\DeviceCamera;

use Tobuli\Repositories\EloquentRepositoryInterface;

interface DeviceCameraRepositoryInterface extends EloquentRepositoryInterface {

}
