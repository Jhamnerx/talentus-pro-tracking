<?php namespace Tobuli\Repositories\SensorGroup;

use Tobuli\Repositories\EloquentRepositoryInterface;

interface SensorGroupRepositoryInterface extends EloquentRepositoryInterface {

}