<?php namespace Tobuli\Repositories\DeviceSensor;

use Tobuli\Repositories\EloquentRepositoryInterface;

interface DeviceSensorRepositoryInterface extends EloquentRepositoryInterface {
}