<?php namespace Tobuli\Repositories\PoiGroup;

use Tobuli\Repositories\EloquentRepositoryInterface;

interface PoiGroupRepositoryInterface extends EloquentRepositoryInterface {

}