<?php namespace Tobuli\Repositories\ApnConfig;

use Tobuli\Repositories\EloquentRepositoryInterface;

interface ApnConfigRepositoryInterface extends EloquentRepositoryInterface {

}
