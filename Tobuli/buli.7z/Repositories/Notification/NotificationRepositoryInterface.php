<?php namespace Tobuli\Repositories\Notification;

use Tobuli\Repositories\EloquentRepositoryInterface;

interface NotificationRepositoryInterface extends EloquentRepositoryInterface {


}