<?php

namespace Tobuli\Helpers\Templates\Builders;

class ExpiringSimTemplate extends ExpiringDeviceTemplate
{
}