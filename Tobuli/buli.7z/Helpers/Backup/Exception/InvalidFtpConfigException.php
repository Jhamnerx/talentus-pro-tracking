<?php

namespace Tobuli\Helpers\Backup\Exception;

class InvalidFtpConfigException extends \Exception
{
}