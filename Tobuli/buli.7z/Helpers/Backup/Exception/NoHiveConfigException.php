<?php

namespace Tobuli\Helpers\Backup\Exception;

class NoHiveConfigException extends \Exception
{
}