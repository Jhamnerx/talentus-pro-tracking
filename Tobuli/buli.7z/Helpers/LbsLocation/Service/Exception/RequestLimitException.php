<?php

namespace Tobuli\Helpers\LbsLocation\Service\Exception;

class RequestLimitException extends \Exception
{
}