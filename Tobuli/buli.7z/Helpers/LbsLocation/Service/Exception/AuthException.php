<?php

namespace Tobuli\Helpers\LbsLocation\Service\Exception;

class AuthException extends \Exception
{
}