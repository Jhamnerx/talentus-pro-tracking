<?php

namespace Tobuli\Helpers\RemoteFileManager\Exception;

class FailedLoginException extends \Exception
{
}