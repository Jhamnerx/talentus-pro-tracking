<?php

namespace Tobuli\Helpers\RemoteFileManager\Exception;

class NoConnectionException extends \Exception
{
}