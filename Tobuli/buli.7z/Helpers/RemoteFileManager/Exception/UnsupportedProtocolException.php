<?php

namespace Tobuli\Helpers\RemoteFileManager\Exception;

class UnsupportedProtocolException extends \Exception
{
}